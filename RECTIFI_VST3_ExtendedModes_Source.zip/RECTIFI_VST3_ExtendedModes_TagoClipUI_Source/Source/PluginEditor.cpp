#include "PluginEditor.h"
#include "BinaryData.h"

#include <algorithm>
#include <cmath>
#include <utility>

namespace
{
    constexpr int designWidth = 620;
    constexpr int designHeight = 430;
    constexpr float designRatio = static_cast<float>(designWidth) / static_cast<float>(designHeight);

    const juce::Colour bg        { 0xff12100e };
    const juce::Colour bgDeep    { 0xff0a0908 };
    const juce::Colour surface   { 0xff1a1815 };
    const juce::Colour text      { 0xffece7de };
    const juce::Colour textHi    { 0xfff2eee6 };
    const juce::Colour accent    { 0xff00fddc };
    const juce::Colour accent2   { 0xff00d2c4 };
    const juce::Colour hairline  { 0x23ece7de };
    const juce::Colour dim       { 0x73ece7de };
    const juce::Colour faint     { 0x3dece7de };

    constexpr float pi = juce::MathConstants<float>::pi;
    constexpr float knobStart = -135.0f * pi / 180.0f;
    constexpr float knobSweep = 270.0f * pi / 180.0f;

    juce::Typeface::Ptr archivoFace()
    {
        static auto face = juce::Typeface::createSystemTypefaceFor(
            BinaryData::ArchivoRegular_ttf,
            static_cast<std::size_t>(BinaryData::ArchivoRegular_ttfSize));
        return face;
    }

    juce::Typeface::Ptr martianFace(bool bold)
    {
        if (bold)
        {
            static auto face = juce::Typeface::createSystemTypefaceFor(
                BinaryData::MartianMonoBold_ttf,
                static_cast<std::size_t>(BinaryData::MartianMonoBold_ttfSize));
            return face;
        }
        static auto face = juce::Typeface::createSystemTypefaceFor(
            BinaryData::MartianMonoRegular_ttf,
            static_cast<std::size_t>(BinaryData::MartianMonoRegular_ttfSize));
        return face;
    }

    juce::Font archivoFont(float size, bool bold = false)
    {
        juce::Font font(archivoFace());
        font.setHeight(size);
        if (bold)
            font.setBold(true);
        return font;
    }

    juce::Font monoFont(float size, bool bold = true)
    {
        juce::Font font(martianFace(bold));
        font.setHeight(size);
        return font;
    }

    juce::Point<float> knobPoint(float cx, float cy, float radius, float angle)
    {
        return { cx + std::sin(angle) * radius, cy - std::cos(angle) * radius };
    }

    juce::Path makeArc(float cx, float cy, float radius, float a0, float a1, int steps = 64)
    {
        juce::Path path;
        if (a1 < a0)
            std::swap(a0, a1);
        for (int i = 0; i <= steps; ++i)
        {
            const float fraction = static_cast<float>(i) / static_cast<float>(steps);
            const auto point = knobPoint(cx, cy, radius, a0 + (a1 - a0) * fraction);
            if (i == 0) path.startNewSubPath(point);
            else path.lineTo(point);
        }
        return path;
    }

    void setSmallLabel(juce::Label& label, const juce::String& value, float size,
                       juce::Colour colour,
                       juce::Justification justification = juce::Justification::centredLeft)
    {
        label.setText(value, juce::dontSendNotification);
        label.setFont(monoFont(size));
        label.setColour(juce::Label::textColourId, colour);
        label.setJustificationType(justification);
        label.setInterceptsMouseClicks(false, false);
    }

    void setPlainParameter(RectifiAudioProcessor& processor, const juce::String& id, float value)
    {
        if (auto* parameter = processor.parameters.getParameter(id))
            parameter->setValueNotifyingHost(parameter->convertTo0to1(value));
    }
}

RectifiLookAndFeel::RectifiLookAndFeel()
{
    setColour(juce::Slider::rotarySliderFillColourId, accent);
    setColour(juce::Slider::rotarySliderOutlineColourId, faint);
    setColour(juce::Slider::thumbColourId, textHi);
    setColour(juce::TextButton::textColourOffId, dim);
    setColour(juce::TextButton::textColourOnId, accent);
    setColour(juce::ComboBox::backgroundColourId, bgDeep);
    setColour(juce::ComboBox::textColourId, text);
    setColour(juce::ComboBox::outlineColourId, hairline);
}

void RectifiLookAndFeel::drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                                          float sliderPos, float, float, juce::Slider& slider)
{
    const float size = static_cast<float>(juce::jmin(width, height));
    const float cx = static_cast<float>(x) + static_cast<float>(width) * 0.5f;
    const float cy = static_cast<float>(y) + static_cast<float>(height) * 0.5f;
    const bool small = size < 68.0f;
    const float radius = size * (small ? 0.36f : 0.405f);
    const float bezelRadius = radius * 0.85f;
    const float faceRadius = radius * 0.72f;
    const float angle = knobStart + juce::jlimit(0.0f, 1.0f, sliderPos) * knobSweep;

    g.setColour(bgDeep);
    g.fillEllipse(cx - radius - 3.0f, cy - radius - 3.0f,
                  (radius + 3.0f) * 2.0f, (radius + 3.0f) * 2.0f);
    g.setColour(juce::Colour(0xff25211b));
    g.drawEllipse(cx - radius - 2.0f, cy - radius - 2.0f,
                  (radius + 2.0f) * 2.0f, (radius + 2.0f) * 2.0f, 1.0f);

    if (!small)
    {
        constexpr int ticks = 24;
        for (int i = 0; i <= ticks; ++i)
        {
            const float a = knobStart + knobSweep * static_cast<float>(i) / static_cast<float>(ticks);
            const bool major = (i % 6) == 0;
            const auto p1 = knobPoint(cx, cy, radius + (major ? 1.0f : 2.0f), a);
            const auto p2 = knobPoint(cx, cy, radius + 5.0f, a);
            g.setColour(major ? dim : faint);
            g.drawLine(p1.x, p1.y, p2.x, p2.y, major ? 1.35f : 0.8f);
        }
    }

    juce::ColourGradient bezelGradient(juce::Colour(0xff3a352c), cx, cy - radius,
                                       juce::Colour(0xff15130f), cx, cy + radius, false);
    bezelGradient.addColour(0.50, juce::Colour(0xff15130f));
    bezelGradient.addColour(1.00, juce::Colour(0xff2a261f));
    g.setGradientFill(bezelGradient);
    g.fillEllipse(cx - bezelRadius, cy - bezelRadius, bezelRadius * 2.0f, bezelRadius * 2.0f);
    g.setColour(hairline);
    g.drawEllipse(cx - bezelRadius, cy - bezelRadius, bezelRadius * 2.0f, bezelRadius * 2.0f, 1.0f);

    juce::ColourGradient faceGradient(juce::Colour(0xff2e2921), cx, cy - faceRadius,
                                      juce::Colour(0xff080707), cx, cy + faceRadius, true);
    faceGradient.addColour(0.45, juce::Colour(0xff1c1916));
    faceGradient.addColour(0.85, juce::Colour(0xff0e0c0b));
    g.setGradientFill(faceGradient);
    g.fillEllipse(cx - faceRadius, cy - faceRadius, faceRadius * 2.0f, faceRadius * 2.0f);
    g.setColour(hairline);
    g.drawEllipse(cx - faceRadius, cy - faceRadius, faceRadius * 2.0f, faceRadius * 2.0f, 0.8f);

    const bool bipolar = slider.getMinimum() < 0.0 && slider.getMaximum() > 0.0;
    float fillStart = knobStart;
    if (bipolar)
        fillStart = knobStart + knobSweep * static_cast<float>(slider.valueToProportionOfLength(0.0));
    g.setColour(faint);
    g.strokePath(makeArc(cx, cy, radius, knobStart, knobStart + knobSweep),
                 juce::PathStrokeType(small ? 1.8f : 2.6f,
                                      juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    const float from = bipolar ? juce::jmin(fillStart, angle) : knobStart;
    const float to = bipolar ? juce::jmax(fillStart, angle) : angle;
    if (to - from > 0.005f)
    {
        g.setColour(accent.withAlpha(0.22f));
        g.strokePath(makeArc(cx, cy, radius, from, to), juce::PathStrokeType(small ? 2.0f : 3.0f,
                              juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        g.setColour(accent);
        g.strokePath(makeArc(cx, cy, radius, from, to), juce::PathStrokeType(small ? 1.5f : 2.0f,
                              juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    }

    if (bipolar && !small)
    {
        const auto zero = knobPoint(cx, cy, radius, 0.0f);
        g.setColour(faint);
        g.fillEllipse(zero.x - 1.5f, zero.y - 1.5f, 3.0f, 3.0f);
    }

    const auto p0 = knobPoint(cx, cy, radius * 0.42f, angle);
    const auto p1 = knobPoint(cx, cy, radius * 0.70f, angle);
    g.setColour(accent.withAlpha(0.18f));
    g.drawLine(p0.x, p0.y, p1.x, p1.y, small ? 3.4f : 5.2f);
    g.setColour(textHi);
    g.drawLine(p0.x, p0.y, p1.x, p1.y, small ? 1.7f : 2.8f);
}

void RectifiLookAndFeel::drawButtonBackground(juce::Graphics& g, juce::Button& button,
                                               const juce::Colour&, bool highlighted, bool down)
{
    const auto bounds = button.getLocalBounds().toFloat().reduced(0.5f);
    const auto name = button.getName();
    const bool isPower = name == "power";
    const bool isDelta = name == "delta-btn";
    const bool isPresetNav = name == "preset-nav";
    const bool isFilter = name == "filter-toggle";
    const bool active = button.getToggleState();
    const float radius = isPower ? bounds.getHeight() * 0.5f : 4.0f;

    juce::Colour fill = bgDeep;
    juce::Colour edge = hairline;
    if (active && (isDelta || isFilter))
    {
        fill = accent;
        edge = accent;
    }
    else if (active)
    {
        fill = surface.brighter(0.08f);
        edge = accent.withAlpha(0.55f);
    }
    else if (highlighted || down)
    {
        fill = surface;
        edge = accent.withAlpha(0.35f);
    }

    g.setColour(fill);
    g.fillRoundedRectangle(bounds, radius);
    g.setColour(edge);
    g.drawRoundedRectangle(bounds, radius, 1.0f);
    if (isPower && active)
    {
        g.setColour(accent.withAlpha(0.16f));
        g.drawEllipse(bounds.reduced(2.0f), 1.5f);
    }
    if (isPresetNav)
        g.setColour(dim);
}

void RectifiLookAndFeel::drawButtonText(juce::Graphics& g, juce::TextButton& button,
                                        bool highlighted, bool down)
{
    const auto name = button.getName();
    const bool active = button.getToggleState();
    const bool isDelta = name == "delta-btn";
    const bool isPower = name == "power";
    const bool isMode = name == "mode-chip";
    const bool isOversampling = name == "os-toggle";
    const bool isPresetNav = name == "preset-nav";
    const bool isPresetSave = name == "preset-save";
    const bool isFilter = name == "filter-toggle";

    juce::Colour colour = dim;
    if (active && isDelta) colour = bgDeep;
    else if (active && isFilter) colour = bgDeep;
    else if (active || highlighted || down) colour = accent;
    else if (isPower) colour = accent;

    const float factor = uiScale;
    if (isPower)
    {
        // Draw a real vector power glyph; no Unicode font glyph is involved.
        const auto b = button.getLocalBounds().toFloat();
        const float cx = b.getCentreX();
        const float cy = b.getCentreY() + 1.0f * factor;
        const float r = 6.0f * factor;
        g.setColour(colour);
        g.drawEllipse(cx - r, cy - r, 2.0f * r, 2.0f * r, 1.7f * factor);
        // Open the circle at the top and draw the stem over the opening.
        g.setColour(active ? surface.brighter(0.08f) : bgDeep);
        g.drawLine(cx - 3.0f * factor, cy - r - 1.0f * factor,
                   cx + 3.0f * factor, cy - r - 1.0f * factor, 4.0f * factor);
        g.setColour(colour);
        g.drawLine(cx, cy - r - 3.0f * factor, cx, cy + 0.5f * factor, 1.7f * factor);
        return;
    }

    if (isDelta)
    {
        // Delta icon is a vector triangle followed by a plain ASCII label.
        const auto b = button.getLocalBounds().toFloat();
        const float left = b.getX() + 12.0f * factor;
        const float midY = b.getCentreY();
        juce::Path triangle;
        triangle.startNewSubPath(left, midY + 5.0f * factor);
        triangle.lineTo(left + 5.0f * factor, midY - 5.0f * factor);
        triangle.lineTo(left + 10.0f * factor, midY + 5.0f * factor);
        triangle.closeSubPath();
        g.setColour(colour);
        g.strokePath(triangle, juce::PathStrokeType(1.3f * factor));
        g.setFont(monoFont(9.0f * factor));
        g.drawText("DELTA", juce::Rectangle<int>(juce::roundToInt(left + 13.0f * factor),
                    0, juce::jmax(0, button.getWidth() - juce::roundToInt(left + 16.0f * factor)),
                    button.getHeight()), juce::Justification::centredLeft, false);
        return;
    }

    float fontSize = 10.0f;
    if (isPower) fontSize = 12.0f;
    else if (isOversampling) fontSize = 9.5f;
    else if (isMode) fontSize = 10.0f;
    else if (isPresetNav) fontSize = 11.0f;
    else if (isPresetSave) fontSize = 8.5f;
    else if (isFilter) fontSize = 8.5f;

    g.setColour(colour);
    g.setFont(monoFont(fontSize * factor));
    g.drawFittedText(button.getButtonText(), button.getLocalBounds().reduced(isMode ? 2 : 3),
                     juce::Justification::centred, 1);
}

RectifiAudioProcessorEditor::RectifiAudioProcessorEditor(RectifiAudioProcessor& p)
    : AudioProcessorEditor(&p), processor(p)
{
    setLookAndFeel(&uiLookAndFeel);
    setResizable(true, false);
    if (auto* constrainer = getConstrainer())
    {
        constrainer->setFixedAspectRatio(designRatio);
        constrainer->setSizeLimits(465, 322, 1240, 860);
    }
    setSize(designWidth, designHeight);

    titleLabel.setText("RECTI-FI", juce::dontSendNotification);
    titleLabel.setFont(archivoFont(20.0f, true));
    titleLabel.setColour(juce::Label::textColourId, textHi);
    titleLabel.setInterceptsMouseClicks(false, false);
    addAndMakeVisible(titleLabel);

    setSmallLabel(subtitleLabel, "WAVEFORM RECTIFICATION", 7.8f, dim);
    addAndMakeVisible(subtitleLabel);
    setSmallLabel(gainLabel, "GAIN", 11.0f, dim, juce::Justification::centred);
    setSmallLabel(gainValueLabel, "0.0 dB", 13.0f, accent, juce::Justification::centred);
    gainValueLabel.setFont(monoFont(13.0f, false));
    setSmallLabel(preFilterLabel, "PRE FILTER", 9.5f, dim, juce::Justification::centred);
    setSmallLabel(preFilterValueLabel, "120 Hz", 11.0f, accent, juce::Justification::centred);
    preFilterValueLabel.setFont(monoFont(11.0f, false));
    setSmallLabel(postFilterLabel, "POST FILTER", 9.5f, dim, juce::Justification::centred);
    setSmallLabel(postFilterValueLabel, "18.0 kHz", 11.0f, accent, juce::Justification::centred);
    postFilterValueLabel.setFont(monoFont(11.0f, false));
    presetNameLabel.setText("INIT", juce::dontSendNotification);
    presetNameLabel.setFont(monoFont(10.0f));
    presetNameLabel.setColour(juce::Label::textColourId, text);
    presetNameLabel.setJustificationType(juce::Justification::centred);
    presetNameLabel.setInterceptsMouseClicks(false, false);

    for (auto* label : { &gainLabel, &gainValueLabel, &preFilterLabel, &preFilterValueLabel,
                         &postFilterLabel, &postFilterValueLabel, &presetNameLabel })
        addAndMakeVisible(*label);

    for (auto* slider : { &gainSlider, &mixSlider, &preFilterCutoffSlider, &postFilterCutoffSlider })
    {
        slider->setLookAndFeel(&uiLookAndFeel);
        slider->setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        slider->setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
        slider->setRotaryParameters(knobStart, knobStart + knobSweep, true);
        slider->setColour(juce::Slider::rotarySliderFillColourId, accent);
        slider->setColour(juce::Slider::rotarySliderOutlineColourId, faint);
        slider->setColour(juce::Slider::thumbColourId, textHi);
        addAndMakeVisible(*slider);
    }

    gainSlider.setRange(-18.0, 18.0, 0.01);
    gainSlider.setDoubleClickReturnValue(true, 0.0);
    gainAttachment = std::make_unique<SliderAttachment>(processor.parameters, "gain", gainSlider);
    gainSlider.onValueChange = [this] { updateValueLabels(); markPresetCustom(); };

    mixSlider.setRange(0.0, 100.0, 0.1);
    mixSlider.setDoubleClickReturnValue(true, 100.0);
    mixAttachment = std::make_unique<SliderAttachment>(processor.parameters, "mix", mixSlider);
    mixSlider.onValueChange = [this] { markPresetCustom(); };

    for (auto* slider : { &preFilterCutoffSlider, &postFilterCutoffSlider })
    {
        slider->setRange(rectifi::filterMinimumCutoffHz, rectifi::filterThruCutoffHz, 1.0);
        slider->setSkewFactor(0.25);
        slider->setDoubleClickReturnValue(true, slider == &preFilterCutoffSlider ? 120.0 : 18000.0);
    }
    preFilterCutoffSlider.setTooltip("Pre-Filter low-pass cutoff before rectification. 21 kHz / THRU bypasses the filter.");
    postFilterCutoffSlider.setTooltip("Post-Filter low-pass cutoff after Gain. 21 kHz / THRU bypasses the filter.");
    preFilterCutoffAttachment = std::make_unique<SliderAttachment>(processor.parameters, "preFilterCutoff", preFilterCutoffSlider);
    postFilterCutoffAttachment = std::make_unique<SliderAttachment>(processor.parameters, "postFilterCutoff", postFilterCutoffSlider);
    preFilterCutoffSlider.onValueChange = [this] { updateValueLabels(); markPresetCustom(); };
    postFilterCutoffSlider.onValueChange = [this] { updateValueLabels(); markPresetCustom(); };

    modeBox.addItemList({ "Positive", "Negative", "Alternate", "Alt-Max",
                          "Positive Half-Wave", "Negative Half-Wave", "Soft Rectify" }, 1);
    modeAttachment = std::make_unique<ComboAttachment>(processor.parameters, "mode", modeBox);
    oversamplingBox.addItemList({ "Off", "2x", "4x", "8x" }, 1);
    oversamplingAttachment = std::make_unique<ComboAttachment>(processor.parameters, "oversampling", oversamplingBox);

    auto setupModeButton = [this](juce::TextButton& button, int modeIndex)
    {
        button.setName("mode-chip");
        button.setClickingTogglesState(true);
        button.setRadioGroupId(41);
        button.setLookAndFeel(&uiLookAndFeel);
        button.setColour(juce::TextButton::buttonColourId, bgDeep);
        button.setColour(juce::TextButton::buttonOnColourId, surface);
        button.setColour(juce::TextButton::textColourOffId, dim);
        button.setColour(juce::TextButton::textColourOnId, accent);
        button.onClick = [this, modeIndex] { chooseMode(modeIndex); };
        addAndMakeVisible(button);
    };
    for (int i = 0; i < static_cast<int>(modeButtons.size()); ++i)
        setupModeButton(*modeButtons[static_cast<std::size_t>(i)], i);
    for (int i = 0; i < static_cast<int>(extendedModeButtons.size()); ++i)
        setupModeButton(*extendedModeButtons[static_cast<std::size_t>(i)], i + 4);

    oversamplingButton.setName("os-toggle");
    oversamplingButton.setLookAndFeel(&uiLookAndFeel);
    oversamplingButton.onClick = [this] { cycleOversampling(); markPresetCustom(); };
    addAndMakeVisible(oversamplingButton);

    deltaButton.setName("delta-btn");
    deltaButton.setButtonText("DELTA");
    deltaButton.setClickingTogglesState(true);
    deltaButton.setLookAndFeel(&uiLookAndFeel);
    deltaAttachment = std::make_unique<ButtonAttachment>(processor.parameters, "delta", deltaButton);
    addAndMakeVisible(deltaButton);

    bypassButton.setName("power");
    bypassButton.setButtonText(juce::String());
    bypassButton.setTooltip("Bypass");
    bypassButton.setClickingTogglesState(true);
    bypassButton.setLookAndFeel(&uiLookAndFeel);
    bypassAttachment = std::make_unique<ButtonAttachment>(processor.parameters, "bypass", bypassButton);
    addAndMakeVisible(bypassButton);

    previousPresetButton.setName("preset-nav");
    nextPresetButton.setName("preset-nav");
    savePresetButton.setName("preset-save");
    for (auto* button : { &previousPresetButton, &nextPresetButton, &savePresetButton })
    {
        button->setLookAndFeel(&uiLookAndFeel);
        addAndMakeVisible(*button);
    }
    previousPresetButton.setTooltip("Previous preset");
    nextPresetButton.setTooltip("Next preset");
    savePresetButton.setTooltip("Save current settings as a user preset");
    previousPresetButton.onClick = [this] { cyclePreset(-1); };
    nextPresetButton.onClick = [this] { cyclePreset(1); };
    savePresetButton.onClick = [this] { savePresetFromDialog(); };

    preFilterEnableButton.setName("filter-toggle");
    postFilterEnableButton.setName("filter-toggle");
    for (auto* button : { &preFilterEnableButton, &postFilterEnableButton })
    {
        button->setClickingTogglesState(true);
        button->setLookAndFeel(&uiLookAndFeel);
        addAndMakeVisible(*button);
        button->onClick = [this] { markPresetCustom(); };
    }
    preFilterEnableAttachment = std::make_unique<ButtonAttachment>(processor.parameters, "preFilterEnabled", preFilterEnableButton);
    postFilterEnableAttachment = std::make_unique<ButtonAttachment>(processor.parameters, "postFilterEnabled", postFilterEnableButton);

    refreshPresetNames();
    updateValueLabels();
    synchroniseControls();
    startTimerHz(30);
}

RectifiAudioProcessorEditor::~RectifiAudioProcessorEditor()
{
    stopTimer();
    setLookAndFeel(nullptr);
    for (auto* slider : { &gainSlider, &mixSlider, &preFilterCutoffSlider, &postFilterCutoffSlider })
        slider->setLookAndFeel(nullptr);
    for (auto* button : modeButtons) button->setLookAndFeel(nullptr);
    for (auto* button : extendedModeButtons) button->setLookAndFeel(nullptr);
    for (auto* button : { &oversamplingButton, &deltaButton, &bypassButton, &previousPresetButton,
                          &nextPresetButton, &savePresetButton, &preFilterEnableButton, &postFilterEnableButton })
        button->setLookAndFeel(nullptr);
}

void RectifiAudioProcessorEditor::chooseMode(int index)
{
    modeBox.setSelectedItemIndex(juce::jlimit(0, 6, index), juce::sendNotificationSync);
    markPresetCustom();
    synchroniseControls();
    repaint();
}

void RectifiAudioProcessorEditor::cycleOversampling()
{
    const int current = juce::jlimit(0, 3, oversamplingBox.getSelectedItemIndex());
    oversamplingBox.setSelectedItemIndex((current + 1) % 4, juce::sendNotificationSync);
    synchroniseControls();
    repaint();
}

void RectifiAudioProcessorEditor::synchroniseControls()
{
    const int currentMode = juce::jlimit(0, 6, modeBox.getSelectedItemIndex());
    for (int i = 0; i < static_cast<int>(modeButtons.size()); ++i)
        modeButtons[static_cast<std::size_t>(i)]->setToggleState(i == currentMode, juce::dontSendNotification);
    for (int i = 0; i < static_cast<int>(extendedModeButtons.size()); ++i)
        extendedModeButtons[static_cast<std::size_t>(i)]->setToggleState(i + 4 == currentMode, juce::dontSendNotification);

    const int osIndex = juce::jlimit(0, 3, oversamplingBox.getSelectedItemIndex());
    const juce::StringArray osNames { "OVERSAMPLING OFF", "OVERSAMPLING 2X", "OVERSAMPLING 4X", "OVERSAMPLING 8X" };
    oversamplingButton.setButtonText(osNames[osIndex]);
    oversamplingButton.setToggleState(osIndex > 0, juce::dontSendNotification);
    preFilterEnableButton.setButtonText(preFilterEnableButton.getToggleState() ? "ON" : "OFF");
    postFilterEnableButton.setButtonText(postFilterEnableButton.getToggleState() ? "ON" : "OFF");
    updateValueLabels();
}

void RectifiAudioProcessorEditor::updateValueLabels()
{
    gainValueLabel.setText((gainSlider.getValue() > 0.0 ? "+" : "")
                               + juce::String(gainSlider.getValue(), 1) + " dB",
                           juce::dontSendNotification);

    const auto preHz = preFilterCutoffSlider.getValue();
    const auto postHz = postFilterCutoffSlider.getValue();
    const auto formatHz = [](double hz)
    {
        if (rectifi::isFilterThru(static_cast<float>(hz)))
            return juce::String("THRU");
        return hz >= 1000.0 ? juce::String(hz / 1000.0, hz >= 10000.0 ? 0 : 1) + " kHz"
                            : juce::String(juce::roundToInt(hz)) + " Hz";
    };
    preFilterValueLabel.setText(formatHz(preHz), juce::dontSendNotification);
    postFilterValueLabel.setText(formatHz(postHz), juce::dontSendNotification);
}

void RectifiAudioProcessorEditor::timerCallback()
{
    const float in = processor.readInputPeak();
    const float out = processor.readOutputPeak();
    inputMeter = in > inputMeter ? inputMeter + (in - inputMeter) * 0.55f : inputMeter * 0.88f;
    outputMeter = out > outputMeter ? outputMeter + (out - outputMeter) * 0.55f : outputMeter * 0.88f;

    if (in >= inputPeakHold) { inputPeakHold = in; inputPeakHoldFrames = 0; }
    else if (inputPeakHoldFrames++ > 90) inputPeakHold *= 0.985f;
    if (out >= outputPeakHold) { outputPeakHold = out; outputPeakHoldFrames = 0; }
    else if (outputPeakHoldFrames++ > 90) outputPeakHold *= 0.985f;

    synchroniseControls();
    scopePhase += 0.035f;
    if (scopePhase > 2.0f * pi) scopePhase -= 2.0f * pi;
    repaint();
}

void RectifiAudioProcessorEditor::setScaledBounds(juce::Component& component,
                                                   int x, int y, int w, int h, float scale)
{
    component.setBounds(juce::roundToInt(x * scale), juce::roundToInt(y * scale),
                        juce::roundToInt(w * scale), juce::roundToInt(h * scale));
}

void RectifiAudioProcessorEditor::resized()
{
    const float scale = static_cast<float>(getWidth()) / static_cast<float>(designWidth);
    uiLookAndFeel.setUiScale(scale);

    titleLabel.setFont(archivoFont(20.0f * scale, true));
    subtitleLabel.setFont(monoFont(7.8f * scale));
    gainLabel.setFont(monoFont(11.0f * scale));
    gainValueLabel.setFont(monoFont(13.0f * scale, false));
    preFilterLabel.setFont(monoFont(9.5f * scale));
    preFilterValueLabel.setFont(monoFont(11.0f * scale, false));
    postFilterLabel.setFont(monoFont(9.5f * scale));
    postFilterValueLabel.setFont(monoFont(11.0f * scale, false));
    presetNameLabel.setFont(monoFont(10.0f * scale));

    setScaledBounds(titleLabel,       18,  10, 155, 25, scale);
    setScaledBounds(subtitleLabel,    20,  32, 190, 10, scale);
    setScaledBounds(previousPresetButton, 184, 13, 18, 25, scale);
    setScaledBounds(presetNameLabel,  205, 13, 130, 25, scale);
    setScaledBounds(nextPresetButton, 338, 13, 18, 25, scale);
    setScaledBounds(savePresetButton, 359, 13, 36, 25, scale);
    setScaledBounds(mixSlider,        520,  10,  31,  30, scale);
    setScaledBounds(bypassButton,     579,  11,  27,  27, scale);

    setScaledBounds(gainSlider,       315, 111, 100, 100, scale);
    setScaledBounds(gainValueLabel,   305, 211, 120,  18, scale);
    setScaledBounds(gainLabel,        305, 230, 120,  16, scale);

    setScaledBounds(preFilterCutoffSlider, 421, 110, 58, 62, scale);
    setScaledBounds(preFilterLabel,        416, 174, 68, 12, scale);
    setScaledBounds(preFilterValueLabel,   414, 187, 72, 14, scale);
    setScaledBounds(preFilterEnableButton, 424, 204, 52, 19, scale);

    setScaledBounds(postFilterCutoffSlider, 489, 110, 58, 62, scale);
    setScaledBounds(postFilterLabel,        484, 174, 68, 12, scale);
    setScaledBounds(postFilterValueLabel,   482, 187, 72, 14, scale);
    setScaledBounds(postFilterEnableButton, 492, 204, 52, 19, scale);

    const int x = 16, width = 288, height = 27, gap = 5;
    const int chipWidth = (width - 3 * gap) / 4;
    for (int i = 0; i < static_cast<int>(modeButtons.size()); ++i)
        setScaledBounds(*modeButtons[static_cast<std::size_t>(i)], x + i * (chipWidth + gap), 289,
                        chipWidth, height, scale);

    const int extendedGap = 5;
    const int extendedWidth = (width - 2 * extendedGap) / 3;
    for (int i = 0; i < static_cast<int>(extendedModeButtons.size()); ++i)
        setScaledBounds(*extendedModeButtons[static_cast<std::size_t>(i)], x + i * (extendedWidth + extendedGap), 329,
                        extendedWidth, height, scale);

    setScaledBounds(deltaButton, 230, 67, 65, 22, scale);
    setScaledBounds(oversamplingButton, 416, 365, 132, 27, scale);
}

void RectifiAudioProcessorEditor::drawScope(juce::Graphics& g, float scale)
{
    juce::ignoreUnused(scale);
    const juce::Rectangle<float> box(16.0f, 60.0f, 288.0f, 222.0f);
    g.setColour(bgDeep);
    g.fillRoundedRectangle(box, 8.0f);
    g.setColour(hairline);
    g.drawRoundedRectangle(box, 8.0f, 1.0f);

    g.saveState();
    g.reduceClipRegion(box.reduced(1.0f).toNearestInt());

    g.setColour(juce::Colour(0x0cece7de));
    for (float yy = box.getY() + 10.0f; yy < box.getBottom(); yy += 22.0f)
        for (float xx = box.getX() + 10.0f; xx < box.getRight(); xx += 22.0f)
            g.fillEllipse(xx - 0.7f, yy - 0.7f, 1.4f, 1.4f);

    const auto plot = box.reduced(12.0f, 14.0f);
    g.setColour(juce::Colour(0x1cece7de));
    g.drawHorizontalLine(juce::roundToInt(plot.getCentreY()), plot.getX(), plot.getRight());
    g.drawVerticalLine(juce::roundToInt(plot.getCentreX()), plot.getY(), plot.getBottom());

    const int modeIndex = juce::jlimit(0, 6, modeBox.getSelectedItemIndex());
    const auto mode = static_cast<rectifi::Mode>(modeIndex);
    const float mix = static_cast<float>(mixSlider.getValue() / 100.0);
    const float gain = rectifi::gainFromDecibels(static_cast<float>(gainSlider.getValue()));
    const bool delta = deltaButton.getToggleState();
    rectifi::RectifierState previewState;
    previewState.reset();

    constexpr int points = 180;
    constexpr float cycles = 2.0f;
    std::array<float, points + 1> inputs {};
    std::array<float, points + 1> outputs {};
    float maxAbs = 0.70f;
    for (int i = 0; i <= points; ++i)
    {
        const float t = static_cast<float>(i) / static_cast<float>(points);
        const float input = 0.66f * std::sin(scopePhase + t * cycles * 2.0f * pi);
        const float wet = previewState.processSample(input, mode) * gain;
        const float output = delta ? wet - input : input + mix * (wet - input);
        inputs[static_cast<std::size_t>(i)] = input;
        outputs[static_cast<std::size_t>(i)] = output;
        maxAbs = juce::jmax(maxAbs, juce::jmax(std::abs(input), std::abs(output)));
    }

    const float amplitude = plot.getHeight() * 0.39f / maxAbs;
    const auto toPoint = [&plot, amplitude](int i, float sample)
    {
        const float x = plot.getX() + plot.getWidth() * static_cast<float>(i) / static_cast<float>(points);
        const float y = plot.getCentreY() - sample * amplitude;
        return juce::Point<float>(x, y);
    };
    juce::Path inputPath, outputPath;
    for (int i = 0; i <= points; ++i)
    {
        const auto inputPoint = toPoint(i, inputs[static_cast<std::size_t>(i)]);
        const auto outputPoint = toPoint(i, outputs[static_cast<std::size_t>(i)]);
        if (i == 0) { inputPath.startNewSubPath(inputPoint); outputPath.startNewSubPath(outputPoint); }
        else { inputPath.lineTo(inputPoint); outputPath.lineTo(outputPoint); }
    }

    g.setColour(text.withAlpha(0.28f));
    g.strokePath(inputPath, juce::PathStrokeType(1.0f, juce::PathStrokeType::curved,
                                                 juce::PathStrokeType::rounded));
    g.setColour(accent.withAlpha(0.18f));
    g.strokePath(outputPath, juce::PathStrokeType(4.0f, juce::PathStrokeType::curved,
                                                  juce::PathStrokeType::rounded));
    g.setColour(accent);
    g.strokePath(outputPath, juce::PathStrokeType(1.8f, juce::PathStrokeType::curved,
                                                  juce::PathStrokeType::rounded));

    const auto lastPoint = toPoint(points, outputs.back());
    g.setColour(accent.withAlpha(0.18f));
    g.fillEllipse(lastPoint.x - 5.0f, lastPoint.y - 5.0f, 10.0f, 10.0f);
    g.setColour(textHi);
    g.fillEllipse(lastPoint.x - 2.1f, lastPoint.y - 2.1f, 4.2f, 4.2f);

    g.setFont(monoFont(8.5f));
    g.setColour(dim);
    g.drawText("INPUT  /  OUTPUT", juce::Rectangle<int>(28, 67, 126, 12), juce::Justification::centredLeft);
    g.setColour(accent);
    g.drawText(delta ? "WET - DRY" : "RECTIFIED", juce::Rectangle<int>(148, 67, 70, 12), juce::Justification::centredRight);
    g.restoreState();
}

void RectifiAudioProcessorEditor::drawMeters(juce::Graphics& g, float scale)
{
    juce::ignoreUnused(scale);
    const float top = 91.0f;
    const float height = 190.0f;
    const float barWidth = 7.0f;
    const float x1 = 570.0f;
    const float x2 = 585.0f;
    for (const auto& item : { std::pair<float, float>(x1, inputMeter), std::pair<float, float>(x2, outputMeter) })
    {
        const auto meter = juce::Rectangle<float>(item.first, top, barWidth, height);
        g.setColour(bgDeep);
        g.fillRoundedRectangle(meter, 3.5f);
        g.setColour(hairline);
        g.drawRoundedRectangle(meter, 3.5f, 0.8f);
        const float amount = juce::jlimit(0.0f, 1.0f, item.second);
        const float fillHeight = (height - 2.0f) * amount;
        juce::ColourGradient gradient(accent2, meter.getCentreX(), meter.getBottom(),
                                      accent, meter.getCentreX(), meter.getY(), false);
        g.setGradientFill(gradient);
        if (fillHeight > 1.0f)
            g.fillRoundedRectangle(meter.withTrimmedTop(height - fillHeight).reduced(1.0f, 1.0f), 2.0f);

        const float held = item.first == x1 ? inputPeakHold : outputPeakHold;
        const float peakY = meter.getBottom() - 1.0f - (height - 2.0f) * juce::jlimit(0.0f, 1.0f, held);
        g.setColour(textHi.withAlpha(0.86f));
        g.drawLine(meter.getX() - 1.0f, peakY, meter.getRight() + 1.0f, peakY, 1.2f);
    }
    g.setFont(monoFont(9.0f));
    g.setColour(dim);
    g.drawText("IN", 565, 286, 17, 12, juce::Justification::centred);
    g.drawText("OUT", 581, 286, 24, 12, juce::Justification::centred);
}

void RectifiAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(bgDeep);
    const float scale = static_cast<float>(getWidth()) / static_cast<float>(designWidth);
    g.addTransform(juce::AffineTransform::scale(scale));

    g.setColour(bg);
    g.fillRoundedRectangle(0.0f, 0.0f, static_cast<float>(designWidth), static_cast<float>(designHeight), 10.0f);
    g.setColour(hairline);
    g.drawRoundedRectangle(0.5f, 0.5f, static_cast<float>(designWidth - 1), static_cast<float>(designHeight - 1), 10.0f, 1.0f);

    juce::ColourGradient wash(accent2.withAlpha(0.055f), 580.0f, 408.0f,
                              bg.withAlpha(0.0f), 300.0f, 150.0f, true);
    g.setGradientFill(wash);
    g.fillRoundedRectangle(1.0f, 1.0f, 618.0f, 428.0f, 9.0f);

    g.setColour(hairline);
    g.drawHorizontalLine(49, 14.0f, 606.0f);
    g.drawHorizontalLine(408, 14.0f, 606.0f);
    g.setColour(faint);
    g.setFont(monoFont(9.5f));
    g.drawText("RECTIFICATION  /  OUTPUT SHAPE", 322, 78, 218, 13, juce::Justification::centredLeft);
    g.setColour(faint);
    g.setFont(monoFont(9.0f));
    g.drawText("EXTENDED MODES", 16, 318, 110, 8, juce::Justification::centredLeft);

    // Preset capsule uses TagoClip's border and recessed dark fill; its label
    // remains a separate child so the arrow/save controls are fully interactive.
    g.setColour(bgDeep);
    g.fillRoundedRectangle(181.5f, 13.5f, 214.0f, 24.0f, 4.0f);
    g.setColour(hairline);
    g.drawRoundedRectangle(181.5f, 13.5f, 214.0f, 24.0f, 4.0f, 1.0f);

    drawScope(g, scale);
    drawMeters(g, scale);

    g.setColour(dim);
    g.setFont(monoFont(9.5f));
    g.drawText("RECTI-FI", 18, 413, 90, 12, juce::Justification::centredLeft);
}

void RectifiAudioProcessorEditor::markPresetCustom()
{
    if (applyingPreset)
        return;
    currentPresetIndex = -1;
    presetNameLabel.setText("CUSTOM", juce::dontSendNotification);
}

juce::StringArray RectifiAudioProcessorEditor::allPresetNames() const
{
    juce::StringArray names = builtInPresetNames;
    for (const auto& name : processor.getUserPresetNames())
        names.add(name);
    return names;
}

void RectifiAudioProcessorEditor::refreshPresetNames()
{
    const auto names = allPresetNames();
    if (currentPresetIndex >= names.size())
        currentPresetIndex = names.size() > 0 ? names.size() - 1 : 0;
    if (currentPresetIndex >= 0 && currentPresetIndex < names.size())
        presetNameLabel.setText(names[currentPresetIndex], juce::dontSendNotification);
}

void RectifiAudioProcessorEditor::cyclePreset(int direction)
{
    const auto names = allPresetNames();
    if (names.isEmpty())
        return;
    const int base = currentPresetIndex >= 0 ? currentPresetIndex : 0;
    const int target = (base + direction + names.size()) % names.size();
    applyPreset(target);
}

void RectifiAudioProcessorEditor::applyPreset(int index)
{
    const auto names = allPresetNames();
    if (index < 0 || index >= names.size())
        return;

    applyingPreset = true;
    if (index < builtInPresetNames.size())
        applyBuiltInPreset(index);
    else
        processor.loadUserPreset(names[index]);
    currentPresetIndex = index;
    presetNameLabel.setText(names[index].toUpperCase(), juce::dontSendNotification);
    synchroniseControls();
    applyingPreset = false;
}

void RectifiAudioProcessorEditor::applyBuiltInPreset(int index)
{
    int mode = 0;
    switch (index)
    {
        case 1: mode = 0; break; // Positive
        case 2: mode = 1; break; // Negative
        case 3: mode = 2; break; // Alternate
        case 4: mode = 3; break; // Alt-Max
        case 5: mode = 4; break; // Positive half-wave
        case 6: mode = 5; break; // Negative half-wave
        case 7: mode = 6; break; // Soft rectification
        default: mode = 0; break;
    }
    setPlainParameter(processor, "mode", static_cast<float>(mode));
    setPlainParameter(processor, "mix", 100.0f);
    setPlainParameter(processor, "gain", 0.0f);
    setPlainParameter(processor, "oversampling", 0.0f);
    setPlainParameter(processor, "preFilterEnabled", 0.0f);
    setPlainParameter(processor, "preFilterCutoff", 120.0f);
    setPlainParameter(processor, "postFilterEnabled", 0.0f);
    setPlainParameter(processor, "postFilterCutoff", 18000.0f);
}

void RectifiAudioProcessorEditor::savePresetFromDialog()
{
    // JUCE 6.1.6 uses asynchronous modal callbacks instead of runModalLoop().
    auto* dialog = new juce::AlertWindow("Save RECTI-FI Preset",
                                          "Name this preset:",
                                          juce::AlertWindow::NoIcon);
    dialog->addTextEditor("presetName", "MY PRESET", "Preset name");
    dialog->addButton("SAVE", 1);
    dialog->addButton("CANCEL", 0);

    juce::Component::SafePointer<RectifiAudioProcessorEditor> safeThis(this);
    dialog->enterModalState(true,
        juce::ModalCallbackFunction::create([safeThis, dialog](int result)
        {
            if (result != 1 || safeThis == nullptr)
                return;

            const auto name = dialog->getTextEditorContents("presetName").trim().substring(0, 32);
            if (name.isEmpty() || !safeThis->processor.saveUserPreset(name))
                return;

            safeThis->refreshPresetNames();
            const auto names = safeThis->allPresetNames();
            for (int i = safeThis->builtInPresetNames.size(); i < names.size(); ++i)
            {
                if (names[i].equalsIgnoreCase(name))
                {
                    safeThis->currentPresetIndex = i;
                    safeThis->presetNameLabel.setText(names[i].toUpperCase(), juce::dontSendNotification);
                    break;
                }
            }
        }),
        true);
}
