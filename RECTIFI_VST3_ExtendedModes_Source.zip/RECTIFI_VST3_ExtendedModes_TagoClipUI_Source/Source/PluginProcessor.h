#pragma once

#include <JuceHeader.h>
#include <array>
#include <atomic>
#include <memory>
#include <vector>

#include "RectifiDSP.h"

class RectifiAudioProcessor final : public juce::AudioProcessor
{
public:
    RectifiAudioProcessor();
    ~RectifiAudioProcessor() override = default;

    void prepareToPlay(double sampleRate, int maximumExpectedSamplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock& destinationData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState parameters;

    // User presets are stored inside the plugin's serialized APVTS state, so
    // they travel with the project/session and do not require external files.
    juce::StringArray getUserPresetNames() const;
    bool saveUserPreset(const juce::String& name);
    bool loadUserPreset(const juce::String& name);

    // Peak snapshots for the editor's meters. Audio thread publishes maxima;
    // editor consumes them at ~30 Hz without locking the audio callback.
    float readInputPeak() noexcept { return inputPeak.exchange(0.0f, std::memory_order_relaxed); }
    float readOutputPeak() noexcept { return outputPeak.exchange(0.0f, std::memory_order_relaxed); }
    juce::AudioProcessorParameter* getBypassParameter() const override { return bypassParameterObject; }

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    void resetRectifierStates() noexcept;
    juce::dsp::Oversampling<float>* getSelectedOversampler(int selection) noexcept;
    int getSelectedLatency(int selection) const noexcept;
    void storePeak(std::atomic<float>& peak, float value) noexcept;

    juce::AudioParameterBool* bypassParameterObject = nullptr;
    std::atomic<float> inputPeak { 0.0f };
    std::atomic<float> outputPeak { 0.0f };

    // Oversampling menu: 0=Off, 1=2x, 2=4x, 3=8x. Instances are allocated
    // and prepared in prepareToPlay; processBlock never recreates them.
    std::array<std::unique_ptr<juce::dsp::Oversampling<float>>, 3> oversamplers;
    juce::AudioBuffer<float> dryScratch;
    juce::dsp::DelayLine<float, juce::dsp::DelayLineInterpolationTypes::None> dryAlignmentDelay { 4096 };
    juce::dsp::StateVariableTPTFilter<float> preFilterProcessor;
    juce::dsp::StateVariableTPTFilter<float> postFilterProcessor;
    std::vector<rectifi::RectifierState> rectifierStates;

    int previousMode = -1;
    int previousOversampling = -1;
    int lastReportedLatency = -1;
    bool previousPreFilterActive = false;
    bool previousPostFilterActive = false;
    double currentSampleRate = 44100.0;
    int maximumBlockSize = 512;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(RectifiAudioProcessor)
};
