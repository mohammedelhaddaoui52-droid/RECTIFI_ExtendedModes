#pragma once

#include <algorithm>
#include <cmath>
#include <cstdint>

namespace rectifi
{
    enum class Mode : int
    {
        positive = 0,
        negative = 1,
        alternate = 2,
        altMax = 3,
        positiveHalf = 4,
        negativeHalf = 5,
        softRectify = 6
    };

    // Fixed softness for the optional Soft Rectify mode. This is intentionally
    // a fixed DSP constant, not a user control, so renders remain repeatable.
    // About -32 dBFS: below this level the transfer curves smoothly through zero.
    constexpr float softRectifyKnee = 0.025f;

    // The official RECTI-FI manual specifies 43 Hz through 21 kHz, with the
    // top position named THRU and functioning as a true filter bypass.
    constexpr float filterMinimumCutoffHz = 43.0f;
    constexpr float filterThruCutoffHz = 21000.0f;

    inline bool isFilterThru(float cutoffHz) noexcept
    {
        return cutoffHz >= filterThruCutoffHz - 0.5f;
    }

    // Keep active filter coefficients safely below Nyquist on low sample-rate
    // hosts. THRU is checked separately and must bypass rather than be clamped.
    inline float safeFilterCutoff(float requestedHz, float sampleRate) noexcept
    {
        const float nyquistGuard = sampleRate > 0.0f ? sampleRate * 0.49f
                                                     : filterThruCutoffHz - 1.0f;
        const float maximumActiveHz = std::min(filterThruCutoffHz - 1.0f,
                                               std::max(filterMinimumCutoffHz, nyquistGuard));
        return std::max(filterMinimumCutoffHz, std::min(requestedHz, maximumActiveHz));
    }

    // Stateful per-channel implementation of the measured RECTI-FI modes.
    // This class intentionally contains no JUCE dependency so its behavior can
    // be unit-tested separately from the plug-in wrapper.
    class RectifierState
    {
    public:
        void reset() noexcept
        {
            polarity_ = 1;
            negativeWasSeen_ = false;
            heldPeak_ = 0.0f;
        }

        float processSample(float input, Mode mode) noexcept
        {
            const float magnitude = std::abs(input);

            switch (mode)
            {
                case Mode::positive:
                    return magnitude;

                case Mode::negative:
                    return -magnitude;

                case Mode::alternate:
                case Mode::altMax:
                    updateTransition(input);
                    if (mode == Mode::alternate)
                        return static_cast<float>(polarity_) * magnitude;

                    heldPeak_ = std::max(heldPeak_, magnitude);
                    return static_cast<float>(polarity_) * heldPeak_;

                case Mode::positiveHalf:
                    return input > 0.0f ? input : 0.0f;

                case Mode::negativeHalf:
                    return input < 0.0f ? input : 0.0f;

                case Mode::softRectify:
                    // Smooth, unipolar full-wave transfer. Unlike abs(x), its
                    // derivative is continuous at zero and exactly zero there.
                    return std::sqrt(input * input + softRectifyKnee * softRectifyKnee)
                           - softRectifyKnee;
            }

            return input;
        }

        int polarity() const noexcept { return polarity_; }
        float heldPeak() const noexcept { return heldPeak_; }

    private:
        void updateTransition(float input) noexcept
        {
            // Based on edge-case renders: toggle on the first sample >= 0
            // after any negative sample. A zero plateau therefore triggers
            // exactly once at its first zero. Falling crossings do not toggle.
            if (input < 0.0f)
            {
                negativeWasSeen_ = true;
                return;
            }

            if (negativeWasSeen_) // input is now >= 0
            {
                polarity_ = -polarity_;
                heldPeak_ = 0.0f;
                negativeWasSeen_ = false;
            }
        }

        int polarity_ = 1;
        bool negativeWasSeen_ = false;
        float heldPeak_ = 0.0f;
    };

    inline float mixLinear(float dry, float wet, float mixPercent) noexcept
    {
        float amount = mixPercent * 0.01f;
        amount = amount < 0.0f ? 0.0f : (amount > 1.0f ? 1.0f : amount);
        return dry + amount * (wet - dry);
    }

    inline float gainFromDecibels(float decibels) noexcept
    {
        return std::pow(10.0f, decibels / 20.0f);
    }

    inline float deltaSignal(float dry, float wet) noexcept
    {
        return wet - dry;
    }
}
