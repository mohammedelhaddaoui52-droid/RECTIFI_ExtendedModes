#include "PluginProcessor.h"
#include "PluginEditor.h"

namespace
{
    constexpr auto modeParameter = "mode";
    constexpr auto mixParameter = "mix";
    constexpr auto gainParameter = "gain";
    constexpr auto deltaParameter = "delta";
    constexpr auto oversamplingParameter = "oversampling";
    constexpr auto preFilterEnabledParameter = "preFilterEnabled";
    constexpr auto preFilterCutoffParameter = "preFilterCutoff";
    constexpr auto postFilterEnabledParameter = "postFilterEnabled";
    constexpr auto postFilterCutoffParameter = "postFilterCutoff";

    const juce::StringArray presetParameterIDs {
        "mode", "mix", "gain", "oversampling",
        "preFilterEnabled", "preFilterCutoff", "postFilterEnabled", "postFilterCutoff"
    };

    int clampChoice(float value, int maximum) noexcept
    {
        return juce::jlimit(0, maximum, juce::roundToInt(value));
    }

    juce::String filterCutoffToText(float value, int maximumLength)
    {
        juce::String result;
        if (rectifi::isFilterThru(value))
            result = "THRU";
        else if (value >= 1000.0f)
            result = juce::String(value / 1000.0f, value >= 10000.0f ? 0 : 1) + " kHz";
        else
            result = juce::String(juce::roundToInt(value)) + " Hz";
        return result.substring(0, juce::jmax(0, maximumLength));
    }

    float filterCutoffFromText(const juce::String& text)
    {
        auto normalized = text.trim().toLowerCase();
        if (normalized == "thru" || normalized == "through")
            return rectifi::filterThruCutoffHz;

        const bool inKiloHertz = normalized.contains("k");
        normalized = normalized.retainCharacters("0123456789.,");
        normalized = normalized.replaceCharacter(',', '.');
        const float value = normalized.getFloatValue() * (inKiloHertz ? 1000.0f : 1.0f);
        return juce::jlimit(rectifi::filterMinimumCutoffHz,
                            rectifi::filterThruCutoffHz, value);
    }
}

RectifiAudioProcessor::RectifiAudioProcessor()
    : AudioProcessor(BusesProperties()
          .withInput("Input", juce::AudioChannelSet::stereo(), true)
          .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      parameters(*this, nullptr, "RECTIFI_STATE", createParameterLayout())
{
    bypassParameterObject = dynamic_cast<juce::AudioParameterBool*>(parameters.getParameter("bypass"));
    jassert(bypassParameterObject != nullptr);
}

juce::AudioProcessorValueTreeState::ParameterLayout RectifiAudioProcessor::createParameterLayout()
{
    using APVTS = juce::AudioProcessorValueTreeState;
    APVTS::ParameterLayout layout;

    layout.add(std::make_unique<juce::AudioParameterChoice>(
        modeParameter, "Rectification",
        juce::StringArray { "Positive", "Negative", "Alternate", "Alt-Max",
                            "Positive Half-Wave", "Negative Half-Wave", "Soft Rectify" }, 0));

    layout.add(std::make_unique<juce::AudioParameterFloat>(
        mixParameter, "Mix",
        juce::NormalisableRange<float> { 0.0f, 100.0f, 0.1f }, 100.0f, "%"));

    layout.add(std::make_unique<juce::AudioParameterFloat>(
        gainParameter, "Gain",
        juce::NormalisableRange<float> { -18.0f, 18.0f, 0.01f }, 0.0f, "dB"));

    layout.add(std::make_unique<juce::AudioParameterBool>(
        deltaParameter, "Delta", false));

    layout.add(std::make_unique<juce::AudioParameterChoice>(
        oversamplingParameter, "Oversampling",
        juce::StringArray { "Off", "2x", "4x", "8x" }, 0));

    layout.add(std::make_unique<juce::AudioParameterBool>(
        preFilterEnabledParameter, "Pre Filter Enabled", false));
    layout.add(std::make_unique<juce::AudioParameterFloat>(
        preFilterCutoffParameter, "Pre Filter Cutoff",
        juce::NormalisableRange<float> { rectifi::filterMinimumCutoffHz, rectifi::filterThruCutoffHz, 1.0f, 0.25f },
        120.0f, "", juce::AudioProcessorParameter::genericParameter,
        filterCutoffToText, filterCutoffFromText));
    layout.add(std::make_unique<juce::AudioParameterBool>(
        postFilterEnabledParameter, "Post Filter Enabled", false));
    layout.add(std::make_unique<juce::AudioParameterFloat>(
        postFilterCutoffParameter, "Post Filter Cutoff",
        juce::NormalisableRange<float> { rectifi::filterMinimumCutoffHz, rectifi::filterThruCutoffHz, 1.0f, 0.25f },
        18000.0f, "", juce::AudioProcessorParameter::genericParameter,
        filterCutoffToText, filterCutoffFromText));

    layout.add(std::make_unique<juce::AudioParameterBool>(
        "bypass", "Bypass", false));

    return layout;
}

bool RectifiAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto input = layouts.getMainInputChannelSet();
    const auto output = layouts.getMainOutputChannelSet();

    if (input != output)
        return false;

    return input == juce::AudioChannelSet::mono() || input == juce::AudioChannelSet::stereo();
}

void RectifiAudioProcessor::prepareToPlay(double sampleRate, int maximumExpectedSamplesPerBlock)
{
    currentSampleRate = sampleRate;
    maximumBlockSize = juce::jmax(1, maximumExpectedSamplesPerBlock);
    const auto channels = juce::jmax(1, getTotalNumInputChannels());

    dryScratch.setSize(channels, maximumBlockSize, false, false, true);
    rectifierStates.assign(static_cast<std::size_t>(channels), {});
    resetRectifierStates();

    const juce::dsp::ProcessSpec spec {
        sampleRate,
        static_cast<juce::uint32>(maximumBlockSize),
        static_cast<juce::uint32>(channels)
    };

    // High-quality, linear-phase half-band FIR stages; integer latency makes
    // dry/wet alignment deterministic for delta monitoring.
    oversamplers[0] = std::make_unique<juce::dsp::Oversampling<float>>(
        static_cast<std::size_t>(channels), 1,
        juce::dsp::Oversampling<float>::filterHalfBandFIREquiripple, true, true);
    oversamplers[1] = std::make_unique<juce::dsp::Oversampling<float>>(
        static_cast<std::size_t>(channels), 2,
        juce::dsp::Oversampling<float>::filterHalfBandFIREquiripple, true, true);
    oversamplers[2] = std::make_unique<juce::dsp::Oversampling<float>>(
        static_cast<std::size_t>(channels), 3,
        juce::dsp::Oversampling<float>::filterHalfBandFIREquiripple, true, true);

    for (auto& oversampler : oversamplers)
    {
        oversampler->initProcessing(static_cast<std::size_t>(maximumBlockSize));
        oversampler->reset();
    }

    dryAlignmentDelay.prepare(spec);
    dryAlignmentDelay.reset();
    dryAlignmentDelay.setDelay(0.0f);

    // Temporary Phase-2 implementation of the manual's filter topology:
    // pre-filter is low-pass before rectification; post-filter is low-pass after
    // rectification and gain. Both are disabled by default.
    preFilterProcessor.setType(juce::dsp::StateVariableTPTFilterType::lowpass);
    preFilterProcessor.setCutoffFrequency(120.0f);
    preFilterProcessor.setResonance(0.707f);
    preFilterProcessor.prepare(spec);
    preFilterProcessor.reset();

    postFilterProcessor.setType(juce::dsp::StateVariableTPTFilterType::lowpass);
    postFilterProcessor.setCutoffFrequency(18000.0f);
    postFilterProcessor.setResonance(0.707f);
    postFilterProcessor.prepare(spec);
    postFilterProcessor.reset();

    previousMode = -1;
    previousOversampling = -1;
    lastReportedLatency = -1;
    previousPreFilterActive = false;
    previousPostFilterActive = false;
    setLatencySamples(0);
}

void RectifiAudioProcessor::releaseResources()
{
    for (auto& oversampler : oversamplers)
        if (oversampler != nullptr)
            oversampler->reset();
    dryAlignmentDelay.reset();
    preFilterProcessor.reset();
    postFilterProcessor.reset();
    previousPreFilterActive = false;
    previousPostFilterActive = false;
    resetRectifierStates();
}

void RectifiAudioProcessor::resetRectifierStates() noexcept
{
    for (auto& state : rectifierStates)
        state.reset();
}

juce::dsp::Oversampling<float>* RectifiAudioProcessor::getSelectedOversampler(int selection) noexcept
{
    if (selection <= 0 || selection > 3)
        return nullptr;
    return oversamplers[static_cast<std::size_t>(selection - 1)].get();
}

int RectifiAudioProcessor::getSelectedLatency(int selection) const noexcept
{
    if (selection <= 0 || selection > 3)
        return 0;
    const auto& oversampler = oversamplers[static_cast<std::size_t>(selection - 1)];
    return oversampler != nullptr ? juce::roundToInt(oversampler->getLatencyInSamples()) : 0;
}

void RectifiAudioProcessor::storePeak(std::atomic<float>& peak, float value) noexcept
{
    float current = peak.load(std::memory_order_relaxed);
    while (value > current
           && !peak.compare_exchange_weak(current, value, std::memory_order_relaxed))
    {
    }
}

void RectifiAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ignoreUnused(midiMessages);
    juce::ScopedNoDenormals noDenormals;

    const int numInputChannels = getTotalNumInputChannels();
    const int numOutputChannels = getTotalNumOutputChannels();
    const int numSamples = buffer.getNumSamples();

    for (int channel = numInputChannels; channel < numOutputChannels; ++channel)
        buffer.clear(channel, 0, numSamples);

    if (numInputChannels <= 0 || numSamples <= 0)
        return;

    // Defensive fallback for hosts that exceed the block size advertised in prepareToPlay.
    if (dryScratch.getNumChannels() < numInputChannels || dryScratch.getNumSamples() < numSamples)
        dryScratch.setSize(numInputChannels, numSamples, false, false, true);

    float inputBlockPeak = 0.0f;
    for (int channel = 0; channel < numInputChannels; ++channel)
    {
        dryScratch.copyFrom(channel, 0, buffer, channel, 0, numSamples);
        inputBlockPeak = juce::jmax(inputBlockPeak, buffer.getMagnitude(channel, 0, numSamples));
    }
    storePeak(inputPeak, inputBlockPeak);

    const bool bypassEnabled = bypassParameterObject != nullptr && bypassParameterObject->get();

    const int modeIndex = clampChoice(parameters.getRawParameterValue(modeParameter)->load(), 6);
    const int osIndex = clampChoice(parameters.getRawParameterValue(oversamplingParameter)->load(), 3);
    const float mixAmount = juce::jlimit(0.0f, 100.0f, parameters.getRawParameterValue(mixParameter)->load()) * 0.01f;
    const float gainDb = juce::jlimit(-18.0f, 18.0f, parameters.getRawParameterValue(gainParameter)->load());
    const float wetGain = rectifi::gainFromDecibels(gainDb);
    const bool deltaEnabled = parameters.getRawParameterValue(deltaParameter)->load() >= 0.5f;
    const bool preFilterEnabled = parameters.getRawParameterValue(preFilterEnabledParameter)->load() >= 0.5f;
    const bool postFilterEnabled = parameters.getRawParameterValue(postFilterEnabledParameter)->load() >= 0.5f;
    const float preCutoff = juce::jlimit(rectifi::filterMinimumCutoffHz, rectifi::filterThruCutoffHz,
        parameters.getRawParameterValue(preFilterCutoffParameter)->load());
    const float postCutoff = juce::jlimit(rectifi::filterMinimumCutoffHz, rectifi::filterThruCutoffHz,
        parameters.getRawParameterValue(postFilterCutoffParameter)->load());

    // THRU at the maximum value is a real bypass, independently of the optional
    // ON/OFF switch. Both are low-pass filters, matching the manual's description.
    const bool preFilterActive = preFilterEnabled && !rectifi::isFilterThru(preCutoff);
    const bool postFilterActive = postFilterEnabled && !rectifi::isFilterThru(postCutoff);
    preFilterProcessor.setCutoffFrequency(rectifi::safeFilterCutoff(preCutoff, static_cast<float>(currentSampleRate)));
    postFilterProcessor.setCutoffFrequency(rectifi::safeFilterCutoff(postCutoff, static_cast<float>(currentSampleRate)));

    // Reset stored filter energy when switching in/out so re-enabling a filter
    // does not resume from a stale internal state after a long bypass interval.
    if (preFilterActive != previousPreFilterActive)
    {
        preFilterProcessor.reset();
        previousPreFilterActive = preFilterActive;
    }
    if (postFilterActive != previousPostFilterActive)
    {
        postFilterProcessor.reset();
        previousPostFilterActive = postFilterActive;
    }

    const auto mode = static_cast<rectifi::Mode>(modeIndex);

    if (modeIndex != previousMode)
    {
        resetRectifierStates();
        previousMode = modeIndex;
    }

    if (osIndex != previousOversampling)
    {
        if (auto* selected = getSelectedOversampler(osIndex))
            selected->reset();
        dryAlignmentDelay.reset();
        resetRectifierStates();
        previousOversampling = osIndex;
    }

    auto* selectedOversampler = getSelectedOversampler(osIndex);
    const int activeLatency = getSelectedLatency(osIndex);

    // Report latency changes to hosts when the oversampling choice changes.
    // The oversampling instances are preallocated; the audio callback does not recreate DSP objects.
    if (activeLatency != lastReportedLatency)
    {
        setLatencySamples(activeLatency);
        lastReportedLatency = activeLatency;
    }
    dryAlignmentDelay.setDelay(static_cast<float>(activeLatency));

    // PRE-FILTER: low-pass high-frequency content before rectification. The dry
    // path stays untouched, so Mix=0 remains the original input.
    if (preFilterActive)
    {
        for (int channel = 0; channel < numInputChannels; ++channel)
        {
            auto* samples = buffer.getWritePointer(channel);
            for (int sample = 0; sample < numSamples; ++sample)
                samples[sample] = preFilterProcessor.processSample(channel, samples[sample]);
        }
    }

    if (selectedOversampler != nullptr)
    {
        juce::dsp::AudioBlock<float> baseBlock(buffer);
        auto oversampledBlock = selectedOversampler->processSamplesUp(baseBlock);

        for (int channel = 0; channel < numInputChannels; ++channel)
        {
            auto* samples = oversampledBlock.getChannelPointer(static_cast<std::size_t>(channel));
            auto& state = rectifierStates[static_cast<std::size_t>(channel)];
            for (std::size_t sample = 0; sample < oversampledBlock.getNumSamples(); ++sample)
                samples[sample] = state.processSample(samples[sample], mode);
        }

        selectedOversampler->processSamplesDown(baseBlock);
    }
    else
    {
        for (int channel = 0; channel < numInputChannels; ++channel)
        {
            auto* samples = buffer.getWritePointer(channel);
            auto& state = rectifierStates[static_cast<std::size_t>(channel)];
            for (int sample = 0; sample < numSamples; ++sample)
                samples[sample] = state.processSample(samples[sample], mode);
        }
    }

    // GAIN: manual specifies gain before the signal reaches the POST-FILTER.
    // Apply it to the wet signal after rectification/downsampling, then low-pass
    // the gain-adjusted result. The dry path is not gain-adjusted.
    for (int channel = 0; channel < numInputChannels; ++channel)
    {
        auto* samples = buffer.getWritePointer(channel);
        for (int sample = 0; sample < numSamples; ++sample)
        {
            const float gainAdjusted = samples[sample] * wetGain;
            samples[sample] = postFilterActive
                ? postFilterProcessor.processSample(channel, gainAdjusted)
                : gainAdjusted;
        }
    }

    // Sample-major traversal keeps each wet/dry pair aligned at the same
    // base-rate sample. JUCE stores DelayLine read/write positions per channel.
    for (int sample = 0; sample < numSamples; ++sample)
    {
        for (int channel = 0; channel < numInputChannels; ++channel)
        {
            float alignedDry = dryScratch.getSample(channel, sample);
            if (selectedOversampler != nullptr && activeLatency > 0)
            {
                dryAlignmentDelay.pushSample(channel, alignedDry);
                alignedDry = dryAlignmentDelay.popSample(channel);
            }

            const float wet = buffer.getSample(channel, sample); // Gain already applied before Post-Filter.
            const float output = bypassEnabled ? alignedDry
                : (deltaEnabled ? rectifi::deltaSignal(alignedDry, wet)
                                : alignedDry + mixAmount * (wet - alignedDry));
            buffer.setSample(channel, sample, output);
        }
    }

    float outputBlockPeak = 0.0f;
    for (int channel = 0; channel < numOutputChannels; ++channel)
        outputBlockPeak = juce::jmax(outputBlockPeak, buffer.getMagnitude(channel, 0, numSamples));
    storePeak(outputPeak, outputBlockPeak);
}

juce::AudioProcessorEditor* RectifiAudioProcessor::createEditor()
{
    return new RectifiAudioProcessorEditor(*this);
}

void RectifiAudioProcessor::getStateInformation(juce::MemoryBlock& destinationData)
{
    juce::MemoryOutputStream stream(destinationData, true);
    parameters.state.writeToStream(stream);
}

void RectifiAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    const auto tree = juce::ValueTree::readFromData(data, static_cast<std::size_t>(sizeInBytes));
    if (tree.isValid() && tree.hasType(parameters.state.getType()))
    {
        parameters.replaceState(tree);
        previousMode = -1;
        previousOversampling = -1;
    }
}


juce::StringArray RectifiAudioProcessor::getUserPresetNames() const
{
    juce::StringArray names;
    const auto presets = parameters.state.getChildWithName("USER_PRESETS");
    if (!presets.isValid())
        return names;
    for (int i = 0; i < presets.getNumChildren(); ++i)
        names.add(presets.getChild(i).getProperty("name").toString());
    return names;
}

bool RectifiAudioProcessor::saveUserPreset(const juce::String& rawName)
{
    const auto name = rawName.trim().substring(0, 32);
    if (name.isEmpty())
        return false;

    auto presets = parameters.state.getChildWithName("USER_PRESETS");
    if (!presets.isValid())
    {
        presets = juce::ValueTree("USER_PRESETS");
        parameters.state.addChild(presets, -1, nullptr);
    }

    juce::ValueTree preset("PRESET");
    preset.setProperty("name", name, nullptr);
    for (const auto& id : presetParameterIDs)
    {
        if (const auto* value = parameters.getRawParameterValue(id))
            preset.setProperty(id, value->load(), nullptr);
    }

    for (int i = presets.getNumChildren() - 1; i >= 0; --i)
    {
        if (presets.getChild(i).getProperty("name").toString().equalsIgnoreCase(name))
        {
            presets.removeChild(i, nullptr);
            break;
        }
    }
    presets.addChild(preset, -1, nullptr);
    return true;
}

bool RectifiAudioProcessor::loadUserPreset(const juce::String& name)
{
    const auto presets = parameters.state.getChildWithName("USER_PRESETS");
    if (!presets.isValid())
        return false;
    for (int i = 0; i < presets.getNumChildren(); ++i)
    {
        const auto preset = presets.getChild(i);
        if (!preset.getProperty("name").toString().equalsIgnoreCase(name))
            continue;

        for (const auto& id : presetParameterIDs)
        {
            if (!preset.hasProperty(id))
                continue;
            if (auto* parameter = parameters.getParameter(id))
            {
                const float plainValue = static_cast<float>(preset.getProperty(id));
                parameter->setValueNotifyingHost(parameter->convertTo0to1(plainValue));
            }
        }
        previousMode = -1;
        previousOversampling = -1;
        return true;
    }
    return false;
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new RectifiAudioProcessor();
}
