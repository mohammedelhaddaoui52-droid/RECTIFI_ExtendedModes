#pragma once

#include <JuceHeader.h>
#include <array>
#include <vector>

#include "PluginProcessor.h"

// Native JUCE rendition of the TagoClip visual system. The exact Archivo and
// Martian Mono typefaces from the provided TagoClip source are embedded.
class RectifiLookAndFeel final : public juce::LookAndFeel_V4
{
public:
    RectifiLookAndFeel();
    void setUiScale(float newScale) noexcept { uiScale = newScale; }

    void drawRotarySlider(juce::Graphics&, int x, int y, int width, int height,
                          float sliderPos, float rotaryStartAngle, float rotaryEndAngle,
                          juce::Slider&) override;
    void drawButtonBackground(juce::Graphics&, juce::Button&, const juce::Colour& backgroundColour,
                              bool shouldDrawButtonAsHighlighted, bool shouldDrawButtonAsDown) override;
    void drawButtonText(juce::Graphics&, juce::TextButton&, bool shouldDrawButtonAsHighlighted,
                        bool shouldDrawButtonAsDown) override;

private:
    float uiScale = 1.0f;
};

class RectifiAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                          private juce::Timer
{
public:
    explicit RectifiAudioProcessorEditor(RectifiAudioProcessor&);
    ~RectifiAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    void chooseMode(int index);
    void cycleOversampling();
    void synchroniseControls();
    void drawScope(juce::Graphics&, float scale);
    void drawMeters(juce::Graphics&, float scale);
    void updateValueLabels();
    void setScaledBounds(juce::Component&, int x, int y, int w, int h, float scale);
    void markPresetCustom();
    void refreshPresetNames();
    void cyclePreset(int direction);
    void applyPreset(int index);
    void applyBuiltInPreset(int index);
    void savePresetFromDialog();
    juce::StringArray allPresetNames() const;

    RectifiAudioProcessor& processor;
    RectifiLookAndFeel uiLookAndFeel;

    juce::Label titleLabel;
    juce::Label subtitleLabel;
    juce::Label gainLabel;
    juce::Label gainValueLabel;
    juce::Label preFilterLabel;
    juce::Label preFilterValueLabel;
    juce::Label postFilterLabel;
    juce::Label postFilterValueLabel;
    juce::Label presetNameLabel;

    juce::Slider gainSlider;
    juce::Slider mixSlider;
    juce::Slider preFilterCutoffSlider;
    juce::Slider postFilterCutoffSlider;
    juce::ComboBox modeBox;          // hidden APVTS attachment target for mode chips
    juce::ComboBox oversamplingBox;  // hidden APVTS attachment target for the OS cycle button

    juce::TextButton positiveButton { "POSITIVE" };
    juce::TextButton negativeButton { "NEGATIVE" };
    juce::TextButton alternateButton { "ALTERNATE" };
    juce::TextButton altMaxButton { "ALT-MAX" };
    juce::TextButton positiveHalfButton { "POS HALF-WAVE" };
    juce::TextButton negativeHalfButton { "NEG HALF-WAVE" };
    juce::TextButton softRectifyButton { "SOFT RECTIFY" };
    juce::TextButton oversamplingButton { "OVERSAMPLING OFF" };
    juce::TextButton deltaButton { "DELTA" };
    juce::TextButton bypassButton;
    juce::TextButton previousPresetButton { "<" };
    juce::TextButton nextPresetButton { ">" };
    juce::TextButton savePresetButton { "SAVE" };
    juce::TextButton preFilterEnableButton { "OFF" };
    juce::TextButton postFilterEnableButton { "OFF" };

    using ComboAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;
    std::unique_ptr<ComboAttachment> modeAttachment;
    std::unique_ptr<ComboAttachment> oversamplingAttachment;
    std::unique_ptr<SliderAttachment> gainAttachment;
    std::unique_ptr<SliderAttachment> mixAttachment;
    std::unique_ptr<SliderAttachment> preFilterCutoffAttachment;
    std::unique_ptr<SliderAttachment> postFilterCutoffAttachment;
    std::unique_ptr<ButtonAttachment> deltaAttachment;
    std::unique_ptr<ButtonAttachment> bypassAttachment;
    std::unique_ptr<ButtonAttachment> preFilterEnableAttachment;
    std::unique_ptr<ButtonAttachment> postFilterEnableAttachment;

    std::array<juce::TextButton*, 4> modeButtons {{
        &positiveButton, &negativeButton, &alternateButton, &altMaxButton
    }};
    std::array<juce::TextButton*, 3> extendedModeButtons {{
        &positiveHalfButton, &negativeHalfButton, &softRectifyButton
    }};
    juce::StringArray builtInPresetNames {
        "INIT", "POSITIVE", "NEGATIVE", "ALTERNATE", "ALT-MAX", "POS HALF-WAVE", "NEG HALF-WAVE", "SOFT RECTIFY"
    };
    int currentPresetIndex = 0;
    bool applyingPreset = false;

    float inputMeter = 0.0f;
    float outputMeter = 0.0f;
    float inputPeakHold = 0.0f;
    float outputPeakHold = 0.0f;
    float scopePhase = 0.0f;
    int inputPeakHoldFrames = 0;
    int outputPeakHoldFrames = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(RectifiAudioProcessorEditor)
};
