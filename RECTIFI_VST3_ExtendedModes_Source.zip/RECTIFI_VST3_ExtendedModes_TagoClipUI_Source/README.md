# RECTI-FI Reconstruction — Extended Modes / TagoClip-style UI

Source version 0.4.0. This is the native JUCE VST3/Standalone source for the RECTI-FI reconstruction. The UI reuses the Archivo and Martian Mono typefaces and the compact dark/mint visual language found in the user-supplied TagoClip 1.1.3 source, while adapting its controls to RECTI-FI. The UI is native JUCE rather than the original React/WebView frontend.

## Rectification modes

The original four modes remain in the first row and keep their original parameter indices for existing session compatibility:

1. **Positive** — full-wave positive rectification, `abs(x)`.
2. **Negative** — full-wave negative rectification, `-abs(x)`.
3. **Alternate** — polarity alternation using the current measured transition rule.
4. **Alt-Max** — alternate-polarity peak holding using the current measured transition rule.

A separate **Extended Modes** row adds:

5. **Positive Half-Wave** — negative input samples become zero.
6. **Negative Half-Wave** — positive input samples become zero.
7. **Soft Rectify** — smooth, unipolar full-wave response `sqrt(x*x + k*k) - k`, with fixed `k = 0.025` (not a user-adjustable control).

The Soft Rectify curve is a newly defined extension, not a claim about an original Pro Tools RECTI-FI mode.

## Other controls

- **Gain:** −18 to +18 dB on the wet path; default 0 dB.
- **Mix:** 0–100% linear-amplitude wet blend; default 100% wet.
- **Delta:** monitors `wet - time-aligned dry`; it is a difference monitor and ignores Mix while active.
- **Oversampling:** Off, 2×, 4×, and 8× using JUCE's maximum-quality equiripple half-band FIR stages.
- **Power/bypass**, mono/stereo support, input/output meters, host parameter automation, and session state persistence.
- **Presets:** factory-style starting presets plus saveable user presets. User preset data is stored in the plugin's serialized state so it travels with a DAW project.
- **Temporary Pre-Filter:** optional 12 dB/octave low-pass before rectification, with a 43 Hz–21 kHz cutoff range; the maximum is THRU/bypass. Disabled by default.
- **Temporary Post-Filter:** optional 12 dB/octave low-pass after rectification and gain, with a 43 Hz–21 kHz cutoff range; the maximum is THRU/bypass. Disabled by default.

The pre/post filters are deliberately preliminary Phase 2 scaffolding. Their temporary implementation uses JUCE 12 dB/octave state-variable low-pass filters and has not been measured against RECTI-FI reference captures. Both are off by default, so the Phase 1 workflow is unchanged unless enabled. Signal flow is input → Pre-Filter → rectification → Gain → Post-Filter → Mix/Delta output. The manual-defined maximum cutoff position (21 kHz) is treated as THRU/bypass.

## TagoClip UI fidelity

The exact Archivo and Martian Mono font files from the supplied TagoClip source were embedded in the native plugin. The UI preserves its dark surface, mint accents, typography family, compact rotary treatment, bordered preset control, mode chips, and slim meters, adapted to the expanded RECTI-FI feature set. The control fonts are scaled with the interface. The mix knob has no adjacent value text; the redundant right footer text and the label above the oversampling selector were removed. Power and Delta symbols are drawn as vector geometry so they do not depend on unsupported Unicode glyphs.

## DSP and test scope

The four original modes remain based on the prior capture-derived implementation. This version adds the three extended modes and the optional filters. The filter behavior has not yet been measured against the original plugin; run Phase 2 reference captures before treating it as equivalent.

The framework-independent DSP test suite covers the original modes, the new half-wave modes, Soft Rectify, Mix, Delta, and gain conversion. Run it without JUCE:

```sh
cmake -S . -B build_dsp -DRECTIFI_BUILD_PLUGIN=OFF -DRECTIFI_BUILD_TESTS=ON
cmake --build build_dsp --config Release
ctest --test-dir build_dsp --output-on-failure
```

## Build for macOS Mojave 10.14.6 (Intel x86_64)

Requirements: Xcode Command Line Tools/Xcode, Git, and CMake 3.15 or newer. JUCE 6.1.6 is fetched on first configure unless supplied locally. On Mojave, run:

```sh
./build_mojave.sh
```

Or configure explicitly:

```sh
cmake -S . -B build_mojave \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_OSX_ARCHITECTURES=x86_64 \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=10.14 \
  -DRECTIFI_BUILD_PLUGIN=ON \
  -DRECTIFI_BUILD_TESTS=ON
cmake --build build_mojave --config Release --target RECTIFI_Reconstruction_VST3 --parallel 2
ctest --test-dir build_mojave --output-on-failure
```

The standalone DSP tests passed in the build environment used for this source package (17/17). The full JUCE plugin build could not be run in this environment because the JUCE source checkout requires network access and GitHub DNS/network access was unavailable. Therefore the final VST3 binary still needs a full JUCE build on macOS or the existing Mojave-compatible CI workflow.

## Parameter IDs

- `mode`: Original four modes (indices 0–3) plus Positive Half-Wave (4), Negative Half-Wave (5), and Soft Rectify (6).
- `gain`: −18 to +18 dB; default 0 dB.
- `mix`: 0–100%; default 100%.
- `delta`: boolean, default off.
- `oversampling`: Off / 2× / 4× / 8×.
- `preFilterEnabled`, `preFilterCutoff`: optional low-pass before rectification, default off / 120 Hz; 21 kHz is THRU.
- `postFilterEnabled`, `postFilterCutoff`: optional low-pass after wet-path Gain, default off / 18 kHz; 21 kHz is THRU.
- `bypass`: boolean, default off.
