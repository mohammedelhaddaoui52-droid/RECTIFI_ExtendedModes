#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
BUILD_DIR="${ROOT}/build_mojave"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "ERROR: This script is intended to build the macOS Mojave x86_64 plugin." >&2
  echo "On macOS, run: ./build_mojave.sh" >&2
  exit 1
fi

if ! command -v cmake >/dev/null 2>&1; then
  echo "ERROR: CMake is required. Install a CMake version compatible with macOS Mojave (3.15 or newer)." >&2
  exit 1
fi
if ! command -v git >/dev/null 2>&1; then
  echo "ERROR: Git is required because CMake downloads the pinned JUCE 6.1.6 dependency." >&2
  exit 1
fi
if ! xcode-select -p >/dev/null 2>&1; then
  echo "ERROR: Xcode Command Line Tools are not configured. Run xcode-select --install." >&2
  exit 1
fi

printf '\n=== RECTI-FI: configure Intel / macOS 10.14 build ===\n'
cmake -S "${ROOT}" -B "${BUILD_DIR}" \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_OSX_ARCHITECTURES=x86_64 \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=10.14 \
  -DRECTIFI_BUILD_PLUGIN=ON \
  -DRECTIFI_BUILD_TESTS=ON

printf '\n=== Build VST3 ===\n'
cmake --build "${BUILD_DIR}" --config Release --target RECTIFI_Reconstruction_VST3 --parallel 2

printf '\n=== Build and run DSP tests ===\n'
cmake --build "${BUILD_DIR}" --config Release --target rectifi_dsp_tests --parallel 2
ctest --test-dir "${BUILD_DIR}" --output-on-failure

printf '\n=== Locate VST3 bundle ===\n'
find "${BUILD_DIR}" -type d -name '*.vst3' -print
printf '\nBuild completed. Use the printed .vst3 path to install/test the plugin.\n'
