#include "../Source/RectifiDSP.h"

#include <array>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

namespace
{
    int failures = 0;

    void check(bool condition, const std::string& label)
    {
        if (condition)
            std::cout << "PASS: " << label << '\n';
        else
        {
            std::cerr << "FAIL: " << label << '\n';
            ++failures;
        }
    }

    bool close(float a, float b, float tolerance = 1.0e-7f)
    {
        return std::abs(a - b) <= tolerance;
    }
}

int main()
{
    using rectifi::Mode;
    using rectifi::RectifierState;

    {
        RectifierState state;
        const std::array<float, 5> input { -1.0f, -0.5f, 0.0f, 0.5f, -0.25f };
        const std::array<float, 5> expected { 1.0f, 0.5f, 0.0f, 0.5f, 0.25f };
        bool ok = true;
        for (std::size_t i = 0; i < input.size(); ++i)
            ok = ok && close(state.processSample(input[i], Mode::positive), expected[i]);
        check(ok, "Positive is abs(input)");
    }

    {
        RectifierState state;
        const std::array<float, 4> input { -1.0f, 0.0f, 0.5f, -0.25f };
        const std::array<float, 4> expected { -1.0f, 0.0f, -0.5f, -0.25f };
        bool ok = true;
        for (std::size_t i = 0; i < input.size(); ++i)
            ok = ok && close(state.processSample(input[i], Mode::negative), expected[i]);
        check(ok, "Negative is -abs(input)");
    }

    {
        RectifierState state;
        const std::array<float, 5> input { -1.0f, -0.5f, 0.0f, 0.5f, 0.25f };
        const std::array<float, 5> expected { 0.0f, 0.0f, 0.0f, 0.5f, 0.25f };
        bool ok = true;
        for (std::size_t i = 0; i < input.size(); ++i)
            ok = ok && close(state.processSample(input[i], Mode::positiveHalf), expected[i]);
        check(ok, "Positive Half-Wave silences negative samples");
    }

    {
        RectifierState state;
        const std::array<float, 5> input { -1.0f, -0.5f, 0.0f, 0.5f, 0.25f };
        const std::array<float, 5> expected { -1.0f, -0.5f, 0.0f, 0.0f, 0.0f };
        bool ok = true;
        for (std::size_t i = 0; i < input.size(); ++i)
            ok = ok && close(state.processSample(input[i], Mode::negativeHalf), expected[i]);
        check(ok, "Negative Half-Wave silences positive samples");
    }

    {
        RectifierState state;
        const float zero = state.processSample(0.0f, Mode::softRectify);
        const float positive = state.processSample(0.1f, Mode::softRectify);
        const float negative = state.processSample(-0.1f, Mode::softRectify);
        check(close(zero, 0.0f) && close(positive, negative) && positive > 0.0f && positive < 0.1f,
              "Soft Rectify is symmetric, continuous at zero, and softer than absolute value near zero");
    }

    {
        RectifierState state;
        const std::array<float, 7> input { -0.8f, -0.4f, 0.0f, 0.3f, -0.2f, -0.1f, 0.0f };
        const std::array<float, 7> expected { 0.8f, 0.4f, -0.0f, -0.3f, -0.2f, -0.1f, 0.0f };
        bool ok = true;
        for (std::size_t i = 0; i < input.size(); ++i)
            ok = ok && close(state.processSample(input[i], Mode::alternate), expected[i]);
        check(ok, "Alternate toggles on negative-to-nonnegative crossing, including exact zero");
    }

    {
        RectifierState state;
        const std::array<float, 7> input { 0.2f, -0.5f, -0.25f, 0.0f, 0.1f, -0.8f, 0.0f };
        // Initial positive state; at the first zero after negative, toggle to
        // negative and reset peak. At the next zero after negative, toggle back.
        const std::array<float, 7> expected { 0.2f, 0.5f, 0.5f, -0.0f, -0.1f, -0.8f, 0.0f };
        bool ok = true;
        for (std::size_t i = 0; i < input.size(); ++i)
            ok = ok && close(state.processSample(input[i], Mode::altMax), expected[i]);
        check(ok, "Alt-Max holds interval peak, resets on state transition, persists through zero");
    }

    check(close(rectifi::mixLinear(2.0f, 4.0f, 0.0f), 2.0f), "Mix 0% is dry");
    check(close(rectifi::mixLinear(2.0f, 4.0f, 100.0f), 4.0f), "Mix 100% is wet");
    check(close(rectifi::mixLinear(2.0f, 4.0f, 25.0f), 2.5f), "Mix is linear amplitude interpolation");
    check(close(rectifi::deltaSignal(0.3f, 0.8f), 0.5f), "Delta is wet minus dry");
    check(close(rectifi::gainFromDecibels(0.0f), 1.0f), "Gain 0 dB preserves the reference level");
    check(close(rectifi::gainFromDecibels(6.0f), 1.9952623f, 1.0e-5f), "Gain conversion uses 20 log10 amplitude convention");
    check(rectifi::isFilterThru(21000.0f) && rectifi::isFilterThru(22000.0f),
          "Filter control maximum is THRU (bypass)");
    check(!rectifi::isFilterThru(20999.0f) && !rectifi::isFilterThru(250.0f),
          "Filter cutoff values below THRU remain active-capable");
    check(close(rectifi::safeFilterCutoff(250.0f, 44100.0f), 250.0f),
          "Safe filter cutoff preserves normal audio-frequency values");
    check(close(rectifi::safeFilterCutoff(20000.0f, 32000.0f), 15680.0f),
          "Safe filter cutoff stays below Nyquist on low-rate hosts");

    constexpr int totalChecks = 17;
    std::cout << "\n" << (totalChecks - failures) << "/" << totalChecks << " tests passed.\n";
    return failures == 0 ? EXIT_SUCCESS : EXIT_FAILURE;
}
