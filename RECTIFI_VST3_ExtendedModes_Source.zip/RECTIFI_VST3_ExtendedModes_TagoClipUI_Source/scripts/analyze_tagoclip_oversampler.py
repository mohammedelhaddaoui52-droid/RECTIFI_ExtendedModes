#!/usr/bin/env python3
"""Reproduce the Kaiser-12 single-pass FIR response values in the review.

Requires NumPy and SciPy. This analyzes the filter taps used by TagoClip's
resample_poly-style oversampler; it does not simulate the whole nonlinear
plugin or measure JUCE's equiripple coefficients.
"""

from __future__ import annotations

import csv
from pathlib import Path

import numpy as np
from scipy.signal import firwin, freqz

FACTORS = (4, 8)
BETA = 12.0
FREQUENCY_RATIOS = (0.50, 0.80, 0.90, 1.00, 1.10, 1.25, 1.50)
OUT = Path(__file__).resolve().parents[1] / "docs" / "tagoclip_kaiser12_response.csv"


def main() -> None:
    rows = []
    for factor in FACTORS:
        taps = firwin(2 * 10 * factor + 1, 1.0 / factor, window=("kaiser", BETA))
        for ratio in FREQUENCY_RATIOS:
            # freqz's normalized angular frequency is relative to the high-rate
            # Nyquist; the high-rate rate is factor times the original sample rate.
            omega = np.pi * ratio / factor
            _, response = freqz(taps, worN=[omega])
            amplitude = max(float(abs(response[0])), 1.0e-20)
            rows.append({
                "oversampling_factor": factor,
                "tap_count": len(taps),
                "frequency_ratio_to_original_nyquist": ratio,
                "magnitude_db": 20.0 * np.log10(amplitude),
            })

    OUT.parent.mkdir(parents=True, exist_ok=True)
    with OUT.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote {OUT}")
    for row in rows:
        if row["oversampling_factor"] == 4:
            print(f"{row['frequency_ratio_to_original_nyquist']:>4.2f}x Nyquist: {row['magnitude_db']:>8.3f} dB")


if __name__ == "__main__":
    main()
