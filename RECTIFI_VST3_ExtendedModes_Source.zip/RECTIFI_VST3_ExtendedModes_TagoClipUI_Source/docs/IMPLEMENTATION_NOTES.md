# Implementation notes and test plan

## Filter and Gain signal flow

The official RECTI-FI manual states that the Pre-Filter removes high frequencies before rectification, Gain adjusts the signal before the Post-Filter, and the Post-Filter removes harmonics above its cutoff. The signal path in this preliminary implementation is therefore:

1. Dry input is copied unchanged for Mix/Delta comparison.
2. Optional 12 dB/octave low-pass Pre-Filter before rectification.
3. Rectification, optionally oversampled.
4. Wet-path Gain: `10^(gainDb / 20)`, adjustable from −18 dB to +18 dB.
5. Optional 12 dB/octave low-pass Post-Filter after Gain.
6. Final Mix or Delta output.

Both cutoff controls run from 43 Hz to 21 kHz. The maximum position is `THRU`, which bypasses the corresponding filter; the separate ON/OFF toggle can also bypass it. Cutoffs are constrained below Nyquist on low-sample-rate hosts. The current filter implementation uses JUCE's state-variable TPT low-pass filter and has not yet been validated against the original plug-in's filter curves or resonance/slope.

Normal output is a linear amplitude blend:

`out = dry + mix * (gainAdjustedWetFiltered - dry)`, where mix is normalized to [0, 1].

Delta output is:

`out = gainAdjustedWetFiltered - dry_aligned`.

When oversampling is active, the dry branch is delayed by the reported oversampling latency so Delta and wet/dry monitoring compare corresponding samples. In Off mode no delay is added.

## Oversampling

The JUCE wrapper constructs three oversampling instances in `prepareToPlay`, with 1/2/3 half-band FIR stages (2x/4x/8x). It uses the highest-quality equiripple FIR configuration with integer latency. The nonlinear rectification runs on the oversampled samples, followed by the oversampler's downsampling filter.

Oversampling necessarily changes the signal behavior relative to the Off path, including state-transition timing because the crossing detector sees the oversampled waveform. This is expected and should be evaluated as a separate fidelity/aliasing trade-off.

## Required validation before calling the build release-ready

1. Render all 44 Phase 1 edge captures through the compiled plugin with Oversampling=Off and Mix=100%, Delta=off. Compare alignment and samples with the reference. Confirm the capture calibration factor is not needed by the DSP.
2. Verify Mix=0% produces the dry signal; Mix=100% matches wet output.
3. Verify Delta equals wet minus time-aligned dry and is independent of Mix.
4. Measure latency for Off/2x/4x/8x in each supported host; verify wet/dry alignment through transients.
5. Run swept-sine and high-frequency sine tests at each oversampling factor. Measure alias components against Off and check for unexpected clipping or non-finite samples.
6. Test sample-rate changes, block-size changes, mono/stereo, plugin state save/restore, automation, and repeated mode changes.

## Legacy macOS toolchain

For a build performed on macOS Mojave, start with JUCE 6.1.6 and the matching Xcode/CMake toolchain. The project requests a 10.14 macOS deployment target. The current JUCE release's published build-host requirements are newer (Xcode 12.4/macOS 10.15.4), so use an appropriate legacy JUCE release or build on a newer machine targeting 10.14. The plugin itself has not been compiled in this environment because no JUCE checkout is available.
