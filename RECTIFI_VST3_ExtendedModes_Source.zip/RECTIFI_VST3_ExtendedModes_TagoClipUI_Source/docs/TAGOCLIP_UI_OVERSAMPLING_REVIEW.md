# TagoClip UI adaptation and oversampling review

## Source inspection

The user-supplied `TagoClip-1.1.3` archive in this turn includes the source tree, including `ui/src/App.css`, `ui/src/fonts/fonts.css`, and the Archivo / Martian Mono WOFF2 files. The public `TagoBeats/TagoClip` source was also inspected for the native wrapper and DSP/oversampling context, including `PluginEditor.cpp`, `PluginProcessor.cpp`, `plugin/dsp/Oversampler.h`, `OversamplerTaps.h`, `scripts/gen_filter_taps.py`, and `measure/analysis/REPORT.md`.

## UI adaptation

The current RECTI-FI project uses a native JUCE editor rather than a WebView/React front end. This avoids adding a web runtime/deployment dependency to the Mojave-oriented C++14 project and keeps the DSP/UI parameter connection native. The editor recreates the key TagoClip visual system and information hierarchy:

- 620 × 430 design canvas with locked aspect ratio and resize scaling to make room for extended modes and temporary pre/post filters.
- Dark near-black surfaces; muted warm-white labels; mint/turquoise accent (`#00FDDC`, secondary `#00D2C4`); subtle border, vignette and dotted grid.
- Machined rotary controls with a 270-degree accent ring, detent/ticks, and separate mono value labels.
- Waveform/scope panel with a dim input waveform and bright processed waveform.
- Original four mode chips plus three separate Extended Modes chips, Delta monitor, compact header Mix control, Gain knob, preset browsing/save controls, oversampling selector, temporary filter controls, narrow input/output meters, and a vector-drawn power/bypass icon.

This is a **native JUCE recreation of TagoClip's UI design language**, adapted to RECTI-FI's controls and taller layout. It is not a pixel-identical port of the React/HTML frontend. The actual Archivo and Martian Mono font files from the supplied source archive are embedded and used by the native UI; font sizes follow corresponding TagoClip CSS roles wherever the control role is analogous. Controls and processing are native JUCE components/parameters.

## Oversampling algorithms compared

### TagoClip source algorithm

TagoClip's `plugin/dsp/Oversampler.h` is a streaming polyphase FIR up/down sampler designed to match `scipy.signal.resample_poly` using a Kaiser window with beta 12. `scripts/gen_filter_taps.py` builds the taps with:

```python
firwin(2 * 10 * L + 1, 1.0 / L, window=("kaiser", 12.0))
```

The checked-in tap arrays have 81 taps for 4× and 161 taps for 8×. Its source comments specify 10 base-rate samples of group delay per direction and a fixed 20-base-sample total processing latency. This implementation has no 2× choice; the factor menu is Off / 4× / 8×.

Using SciPy 1.17.0 to measure the actual Kaiser-12 tap design, the one-pass magnitude response is approximately as shown below. Reproduce these values with `scripts/analyze_tagoclip_oversampler.py`; its output is `docs/tagoclip_kaiser12_response.csv`.

| Frequency relative to the original Nyquist frequency | Kaiser-12 FIR response |
|---:|---:|
| 0.50× | 0.00 dB |
| 0.80× | −0.275 dB |
| 0.90× | −1.753 dB |
| 1.00× | −6.021 dB |
| 1.10× | −14.763 dB |
| 1.25× | −41.526 dB |
| 1.50× | −122.3 dB (approximately) |

These are the single filter's response values, not an end-to-end measurement of the complete nonlinear plug-in. They show that the Kaiser design has excellent far-stopband rejection, but a relatively broad transition region close to Nyquist.

### RECTI-FI current algorithm

The existing RECTI-FI code uses JUCE `dsp::Oversampling<float>` with `filterHalfBandFIREquiripple`, maximum-quality settings, and integer-latency compensation. Factors are built as cascaded half-band stages for 2×, 4× and 8×. JUCE's source configures the high-quality first stage with a narrower transition-width setting than TagoClip's full-band Kaiser design and requests approximately −90 dB upsampling / −75 dB downsampling stopband attenuation at the first stage; later stages use progressively less stringent stage-specific targets. The half-band design is symmetric/linear-phase and can exploit zero-valued alternating taps for efficient processing.

## Decision

**Keep the current JUCE maximum-quality equiripple FIR algorithm. Do not replace it with TagoClip's Kaiser-12 polyphase filter for this version.** The reasons are:

1. A sharper transition closer to the original Nyquist is a useful priority for a rectifier, because rectification generates harmonics that may be folded back into the audible band during downsampling.
2. The half-band cascade is designed for multi-stage 2×/4×/8× operation and has computational optimizations that fit this plugin's oversampling selector.
3. JUCE's integer-latency mode and reported latency give the plugin a supported API for aligning the dry path for Mix/Delta and informing the host.
4. We have not made a controlled render of both algorithms with the RECTI-FI nonlinear modes. Therefore the decision is a code/design-based engineering choice, **not a claim that JUCE wins every objective listening or alias measurement**.

### What still needs measurement before release

- Build the actual VST3 against the intended JUCE version and test it in a DAW.
- At 44.1 kHz, render the same high-frequency sine, sweep, burst and noise stimuli at Off / 2× / 4× / 8×.
- Compare alias-band energy, passband change, transient ringing, CPU load and reported/observed latency.
- Verify dry/wet null alignment and that Delta equals `wet - dry` with oversampling enabled.
- Pay special attention to Alternate and Alt-Max because their state transitions happen in the oversampled sample stream when oversampling is enabled. The Off mode remains the reference path for matching the measured 44.1 kHz captures.

Until this build and render validation is complete, the JUCE plugin/editor wrapper should be treated as source-ready but not release-verified.

## Source references

- [TagoClip polyphase oversampler](https://github.com/TagoBeats/TagoClip/blob/main/plugin/dsp/Oversampler.h)
- [TagoClip FIR tap coefficients](https://github.com/TagoBeats/TagoClip/blob/main/plugin/dsp/OversamplerTaps.h)
- [TagoClip FIR tap generator](https://github.com/TagoBeats/TagoClip/blob/main/scripts/gen_filter_taps.py)
- [JUCE 6.1.6 oversampling stage settings](https://github.com/juce-framework/JUCE/blob/6.1.6/modules/juce_dsp/processors/juce_Oversampling.cpp)
