# macOS Mojave 10.14.6 build

The CMake project pins JUCE 6.1.6 and fetches it automatically if `JUCE_SOURCE_DIR` is not provided. This keeps the project reproducible and avoids depending on whatever JUCE happens to be installed on the build machine. JUCE itself is not bundled in the source ZIP; the first configuration needs internet access and Git.

## One-command build

From Terminal, inside the extracted project folder:

```sh
./build_mojave.sh
```

The script sets the macOS deployment target to 10.14 and the architecture to Intel `x86_64`, configures CMake, builds the VST3 target, and runs the standalone DSP tests. Requirements: compatible Xcode/Command Line Tools, Git, and CMake 3.15+.

## Manual build

```sh
cmake -S . -B build_mojave \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_OSX_ARCHITECTURES=x86_64 \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=10.14 \
  -DRECTIFI_BUILD_PLUGIN=ON \
  -DRECTIFI_BUILD_TESTS=ON
cmake --build build_mojave --config Release --target RECTIFI_Reconstruction_VST3 --parallel 2
ctest --test-dir build_mojave --output-on-failure
find build_mojave -type d -name '*.vst3' -print
```

## Offline build

If JUCE 6.1.6 is already available locally, specify its source directory so the configure step does not have to fetch it:

```sh
cmake -S . -B build_mojave -DJUCE_SOURCE_DIR=/absolute/path/to/JUCE-6.1.6 -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_ARCHITECTURES=x86_64 -DCMAKE_OSX_DEPLOYMENT_TARGET=10.14
cmake --build build_mojave --config Release --target RECTIFI_Reconstruction_VST3 --parallel 2
```

Source configuration is set for the target operating system; it is not a claim that a VST3 binary has already been compiled or host-tested.
