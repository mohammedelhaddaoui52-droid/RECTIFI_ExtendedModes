# Third-party dependency notice

RECTI-FI uses JUCE 6.1.6 for the plug-in wrapper, controls, and oversampling DSP. CMake downloads JUCE from https://github.com/juce-framework/JUCE.git at tag `6.1.6` at configure time unless a local source checkout is supplied via `JUCE_SOURCE_DIR`. JUCE is not vendored in this archive. Review the license applicable to that JUCE version before distribution or commercial use.


The UI embeds the Archivo and Martian Mono fonts converted from the user-supplied TagoClip source package to TTF for native JUCE use.

- Archivo: Copyright 2020 The Archivo Project Authors (Omnibus-Type).
- Martian Mono: Copyright 2021 The Martian Mono Project Authors (Evil Martians).

Both fonts are distributed under the SIL Open Font License, Version 1.1. The complete license text is in `Assets/OFL.txt`.
